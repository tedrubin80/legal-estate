# Legal Estate

Full-stack case management system. See backend and frontend directories.