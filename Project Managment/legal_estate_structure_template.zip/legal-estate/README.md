# Legal Estate

Full-stack legal case management system.