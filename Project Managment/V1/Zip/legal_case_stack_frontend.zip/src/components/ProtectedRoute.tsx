// components/ProtectedRoute.tsx - placeholder content for frontend scaffold
