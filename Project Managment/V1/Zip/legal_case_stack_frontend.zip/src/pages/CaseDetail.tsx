// pages/CaseDetail.tsx - placeholder content for frontend scaffold
